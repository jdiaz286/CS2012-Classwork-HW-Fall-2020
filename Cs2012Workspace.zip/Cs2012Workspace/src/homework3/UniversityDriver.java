/*
 * Name: Jonathan Diaz
 * CIN: 400075634
 * Assignment: Homework 3
 */

package homework3;

public class UniversityDriver {
	public static void main(String[] args) {
		University calStateLA=new University();
		calStateLA.menu();
	}
}

