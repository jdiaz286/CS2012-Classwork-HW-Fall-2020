module Cs2012Workspace {
	exports homework6;
	requires javafx.base;
	requires javafx.graphics;
	requires javafx.controls;
	exports homework7;
	exports homework8and9;
}